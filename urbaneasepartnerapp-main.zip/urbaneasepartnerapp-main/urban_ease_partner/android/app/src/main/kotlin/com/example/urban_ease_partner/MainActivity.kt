package com.example.urban_ease_partner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
