import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:provider/provider.dart';

import 'view/authentication/login_page.dart';
import 'view/nav_page.dart';
import 'view/widgets/theme_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options:const FirebaseOptions(
      apiKey: "AIzaSyApnR3HkdzZxyTF4Yie4AxIvcZAYVIut6M", 
      appId: "289367981388", 
      messagingSenderId:"1:289367981388:android:684a8318a7443324eea3e9", 
      projectId:"urbaneaseapp12",
      // storageBucket: "med-e-care.firebasestorage.app",
    )
  );
  final themeProvider = ThemeProvider();
  await themeProvider.loadTheme();
  runApp(
    // MyApp(isDarkMode: isDarkMode),
    ChangeNotifierProvider(
      create: (_) => themeProvider,//..toggleTheme(isDarkMode),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {

  const MyApp({super.key});

  Future<StatefulWidget> navigate() async { 
    User? user = FirebaseAuth.instance.currentUser; 
    log("$user");
    if (user == null) { 
      return LoginPage(); 
    } else { 
      return NavPage(); 
    } 
  }

  @override
  Widget build(BuildContext context) {
    // log("$isDarkMode");
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child){
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            brightness: Brightness.light,
            primaryColor: const Color(0xFFFFFFFF),
            
            textTheme: const TextTheme(
              bodyLarge: TextStyle(color: Color(0xFF000000)), 
              bodyMedium: TextStyle(color: Color(0xFF000000)),
            ),
            buttonTheme: const ButtonThemeData(textTheme: ButtonTextTheme.accent),
            iconTheme: const IconThemeData(color: Color(0xFF1F1F1F)),
            scaffoldBackgroundColor: const Color(0xFFFFFFFF),
            bottomNavigationBarTheme: const BottomNavigationBarThemeData(
              backgroundColor: Color(0xFFFFFFFF),
              selectedIconTheme: IconThemeData(color: Color(0xFFFFFFFF))),
            extensions: <ThemeExtension<dynamic>>[
              CustomContainerTheme(containerColor: const Color(0xFFF1EFF1)), //const Color(0xFFFAF8FA)
              CustomNavBarTheme(navBarColor: const Color(0xFFFFFFFF)),
            ]
            // Customize other properties for light theme if needed
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            primaryColor: const Color(0xFF353535),
            textTheme: const TextTheme(
              bodyLarge: TextStyle(color: Colors.white), 
              bodyMedium: TextStyle(color: Color(0xFFFFFFFF)),
            ),
            iconTheme: const IconThemeData(color: Color(0xFFFFFFFF)),
            scaffoldBackgroundColor: const Color(0xFF242424),
            bottomNavigationBarTheme: const BottomNavigationBarThemeData(
              backgroundColor: Color(0xFF000000),
              selectedIconTheme: IconThemeData(color: Color(0xFF000000))),
            extensions: <ThemeExtension<dynamic>>[
                CustomContainerTheme(containerColor: Colors.black),   //const Color(0xFF191919)
                CustomNavBarTheme(navBarColor: Colors.grey[850]), // Custom color for containers
            ]
            // Customize other properties for dark theme if needed
          ),
    
          // routes: {
          //   '/search': (context) => const SearchPage(),
          //   '/bookings': (context) => const BookingPage(),
          //   '/notifications': (context) => const NotificationPage(),
          //   '/profile': (context) => const ProfilePage(),
          //   '/settings': (context) => const EditProfilePage(),
          // },
          home: FutureBuilder<Widget>(
            future: navigate(), // Call the async function
            builder: (context, AsyncSnapshot<Widget> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Scaffold(
                  body: Center(
                    child: CircularProgressIndicator(), // Show a loader while waiting
                  ),
                );
              } else if (snapshot.hasError) {
                return Scaffold(
                  body: Center(
                    child: Text('Error: ${snapshot.error}'), // Show error if any
                  ),
                );
              } else if (snapshot.hasData) {
                return snapshot.data!; // Display the resolved widget
              } else {
                return const Scaffold(
                  body: Center(child: Text('Something went wrong!')),
                );
              }
            },
          ),
          themeMode: //isDarkMode ? ThemeMode.dark : ThemeMode.light,
          themeProvider.isDarkMode ? ThemeMode.dark : ThemeMode.light,
          // home: const NavPage(),
        );
      }
    );
  }
}