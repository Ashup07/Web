import 'package:shared_preferences/shared_preferences.dart';

class SessionData {
  static bool? islogin;
  static String? name;

  static Future<void> storeSessionData(
    {required bool loginData, required String nameData}) async{
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

      sharedPreferences.setBool("loginSession", loginData);
      sharedPreferences.setString("name", nameData);

      getSessionData();
  }

  static Future<void> getSessionData() async{
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    islogin = sharedPreferences.getBool("loginSession") ?? false;
    name = sharedPreferences.getString("name") ?? "";
  }
}