
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {

  bool _isDarkMode = false;

  bool get isDarkMode => _isDarkMode;

  Future<void> loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool('isDarkMode') ?? false; // Default to light theme
    notifyListeners();
  }
  
  void toggleTheme()async {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    prefs.setBool('isDarkMode', _isDarkMode);

    // _isDarkMode = !_isDarkMode;
    // await saveThemePreference(_isDarkMode); 
    // log("$_isDarkMode");// Save the preference
    // notifyListeners(); 

  }
}

Future<void> saveThemePreference(bool isDarkMode) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool('isDarkMode', isDarkMode);
}

Future<bool> getThemePreference() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getBool('isDarkMode') ?? false; // Default to light mode
}

class CustomContainerTheme extends ThemeExtension<CustomContainerTheme> {
  final Color? containerColor;

  CustomContainerTheme({this.containerColor});

  @override
  CustomContainerTheme copyWith({Color? containerColor}) {
    return CustomContainerTheme(containerColor: containerColor ?? this.containerColor);
  }

  @override
  CustomContainerTheme lerp(ThemeExtension<CustomContainerTheme>? other, double t) {
    if (other is! CustomContainerTheme) return this;
    return CustomContainerTheme(
      containerColor: Color.lerp(containerColor, other.containerColor, t),
    );
  }
}

class CustomNavBarTheme extends ThemeExtension<CustomNavBarTheme> {
  final Color? navBarColor;

  CustomNavBarTheme({this.navBarColor});

  @override
  CustomNavBarTheme copyWith({Color? navBarColor}) {
    return CustomNavBarTheme(navBarColor: navBarColor ?? this.navBarColor);
  }

  @override
  CustomNavBarTheme lerp(ThemeExtension<CustomNavBarTheme>? other, double t) {
    if (other is! CustomNavBarTheme) return this;
    return CustomNavBarTheme(
      navBarColor: Color.lerp(navBarColor, other.navBarColor, t),
    );
  }
}

