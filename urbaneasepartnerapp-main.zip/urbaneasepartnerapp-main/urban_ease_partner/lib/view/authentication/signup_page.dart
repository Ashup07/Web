import 'dart:developer';
import 'dart:ui';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:urban_ease_partner/view/authentication/about_yourself.dart';

import '../widgets/custom_snackbar.dart';
import '../widgets/theme_provider.dart';
import 'login_page.dart';


class SignupPage extends StatefulWidget{
  const SignupPage({super.key});
  @override  
  State createState() => _SignUpPage();
}

class _SignUpPage extends State{

  final TextEditingController _nameTextEditingController = TextEditingController();
  final TextEditingController _emailTextEditingController = TextEditingController();
  final TextEditingController _passwordTextEditingController = TextEditingController();

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  bool _obsecureText = true;
  @override  
  Widget build(BuildContext context){
    final containerTheme = Theme.of(context).extension<CustomContainerTheme>();
    return Scaffold(
      //backgroundColor: const Color(0xFF60CBB0),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "assets\\image1.jpeg",
              fit: BoxFit.cover,
            )),
          Align(
            alignment: Alignment.bottomCenter,
            child: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 8,sigmaY: 8),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height *0.6,
                  decoration:  BoxDecoration(
                    color: containerTheme?.containerColor != Color(0xFFF1EFF1)?Colors.black.withOpacity(0.7):Color(0xFFF1EFF1).withOpacity(0.7),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(40.0),
                      topRight: Radius.circular(40.0),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height *0.04,
                      left:  MediaQuery.of(context).size.height *0.04,
                      right:  MediaQuery.of(context).size.height *0.04,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Let’s Create Account",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.04,
                            fontWeight: FontWeight.w700,
                            // color: Colors.white
                          ),
                        ),
                        Text(
                          "Hello and Welcome!",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.017,
                            fontWeight: FontWeight.w400,
                            // color: Colors.white
                          ),
                        ),
                        SizedBox(
                        height: MediaQuery.of(context).size.height *0.02,
                      ),
                        Text(
                          "Name",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.017,
                            fontWeight: FontWeight.w400,
                            // color: Colors.white
                          ),
                        ),
                        Container(
                          decoration: const BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 10,
                                spreadRadius: 5,
                                offset: Offset(5, 5)
                              )
                            ]
                          ),
                          child: TextField(
                            controller: _nameTextEditingController,
                            decoration: InputDecoration(
                              prefixIcon: Padding(
                                padding: EdgeInsets.symmetric(
                                  vertical: MediaQuery.of(context).size.height *0.005,
                                  horizontal: MediaQuery.of(context).size.height *0.027,
                                ),
                                child: const Icon(Icons.person_outline_rounded)
                              ),
                              hintText: "Your Name",
                              hintStyle: GoogleFonts.scada(
                                // color: const Color(0xFFA4A4A4), 
                                fontSize: MediaQuery.of(context).size.height *0.02,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              filled: true,
                              fillColor: containerTheme?.containerColor
                            ),
                          ),
                        ),
                        SizedBox(
                        height: MediaQuery.of(context).size.height *0.02,
                      ),
                        Text(
                          "Email",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.017,
                            fontWeight: FontWeight.w400,
                            // color: Colors.white
                          ),
                        ),
                        Container(
                          decoration: const BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 10,
                                spreadRadius: 5,
                                offset: Offset(5, 5)
                              )
                            ]
                          ),
                          child: TextField(
                            controller: _emailTextEditingController,
                            decoration: InputDecoration(
                              prefixIcon: Padding(
                                padding: EdgeInsets.symmetric(
                                  vertical: MediaQuery.of(context).size.height *0.005,
                                  horizontal: MediaQuery.of(context).size.height *0.027,
                                ),
                                child: const Icon(Icons.mail_outline_rounded)
                              ),
                              hintText: "example@gmail.com",
                              hintStyle: GoogleFonts.scada(
                                color: const Color(0xFFA4A4A4), 
                                fontSize: MediaQuery.of(context).size.height *0.02,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              filled: true,
                              fillColor: containerTheme?.containerColor
                            ),
                          ),
                        ),
                        SizedBox(
                        height: MediaQuery.of(context).size.height *0.02,
                      ),
                        Text(
                          "Password",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.017,
                            fontWeight: FontWeight.w400,
                            // color: Colors.white
                          ),
                        ),
                        Container(
                          decoration: const BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 10,
                                spreadRadius: 5,
                                offset: Offset(5, 5)
                              )
                            ]
                          ),
                          child: TextField(
                            controller: _passwordTextEditingController,
                            obscureText: _obsecureText,
                            decoration: InputDecoration(
                              prefixIcon: Padding(
                                padding: EdgeInsets.symmetric(
                                  vertical:  MediaQuery.of(context).size.height *0.005, 
                                  horizontal: MediaQuery.of(context).size.height *0.027,
                                ),
                                child: const Icon(Icons.lock_outline_rounded)
                              ),
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _obsecureText = !_obsecureText;
                                  });
                                },
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                    vertical:  MediaQuery.of(context).size.height *0.005,
                                    horizontal: MediaQuery.of(context).size.height *0.027,
                                  ),
                                  child:_obsecureText ? const Icon(Icons.visibility_rounded) : const Icon(Icons.visibility_off_rounded)
                                ),
                              ),
                              hintText: "at least 6 characters",
                              hintStyle: GoogleFonts.scada(
                                color: const Color(0xFFA4A4A4), 
                                fontSize: MediaQuery.of(context).size.height *0.02,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              filled: true,
                              fillColor: containerTheme?.containerColor
                            ),
                          ),
                        ),
                        SizedBox(
                        height: MediaQuery.of(context).size.height *0.045,
                      ),
                        ElevatedButton(
                            onPressed: () async{
                              if(_nameTextEditingController.text.trim().isNotEmpty && _emailTextEditingController.text.trim().isNotEmpty && _passwordTextEditingController.text.trim().isNotEmpty){
                                try{
                                  UserCredential userCredential = await _firebaseAuth.createUserWithEmailAndPassword(
                                    email: _emailTextEditingController.text.trim(), 
                                    password: _passwordTextEditingController.text.trim()
                                  );

                                  User? user = userCredential.user; 
                                  if (user != null) { 
                                    log("User created: ${user.uid}");
                                    await user.updateProfile(
                                      displayName: _nameTextEditingController.text); 
                                      await user.reload(); 
                                      user = _firebaseAuth.currentUser;
                                      log("User display name after update: ${user?.displayName}");
                                    }
                                  log("USER CRENDENTIALS: $userCredential");

                                  CustomSnackbar.showCustomSnackbar(
                                    message: "User Registered Successfully", 
                                    context: context
                                  );
                                  Navigator.pushReplacement(
                                    context,
                                    PageRouteBuilder(
                                      pageBuilder:(context, animation1, animation2)=> const AboutYourself(),
                                      transitionDuration: Duration.zero,
                                      reverseTransitionDuration: Duration.zero
                                    )
                                  );
                                } on FirebaseAuthException catch(error){
                                  log(error.code);
                                  log("${error.message}");

                                  CustomSnackbar.showCustomSnackbar(
                                    message: error.message!, 
                                    context: context
                                  );
                                }
                              }else {
                                CustomSnackbar.showCustomSnackbar(
                                    message: "Please enter valid fields", 
                                    context: context
                                  );
                              }
                            },
                            style: ButtonStyle(
                              elevation: WidgetStateProperty.all(20),
                              shadowColor: WidgetStateProperty.all(Colors.black),
                              padding: WidgetStateProperty.all<EdgeInsets>(
                                  EdgeInsets.zero),
                              shape: WidgetStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.0),
                                ),
                              ),
                            ),
                            child: Ink(
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [ Color(0xFF9184FF), Color(0xFF786AFA)],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                                child: Container(
                                  constraints: BoxConstraints(
                                    maxWidth: MediaQuery.of(context).size.height *0.42,
                                    minHeight: MediaQuery.of(context).size.height *0.06,
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Create Account',
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.w600,
                                      fontSize: MediaQuery.of(context).size.height *0.03,
                                      color: Colors.white,
                                    ),
                                  ),
                                )
                              )
                            ),
                            SizedBox(height: MediaQuery.of(context).size.height*0.0055),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                GestureDetector(
                                  onTap: (){
                                    Navigator.pushAndRemoveUntil(
                                      context,
                                      PageRouteBuilder(
                                        pageBuilder: (context,animation1,animation2) => const 
                                        LoginPage(),
                                        transitionDuration: Duration.zero,
                                        reverseTransitionDuration: Duration.zero
                                        ),
                                      (Route<dynamic> route) => route.isFirst
                                    );
                                  },
                                  child: RichText(
                                    text: TextSpan(
                                      text: "Already have an account?  ",
                                        style: GoogleFonts.scada(
                                        fontSize: MediaQuery.of(context).size.height *0.017,
                                        fontWeight: FontWeight.w400,
                                        color: Color(0xFF52367F)
                                      ),
                                      children: [
                                        TextSpan(
                                          text: "Log in",
                                          style: GoogleFonts.scada(
                                            fontSize: MediaQuery.of(context).size.height *0.017,
                                            fontWeight: FontWeight.w400,
                                            color:const Color(0xFF52367F),
                                            decoration: TextDecoration.underline,
                                          ),
                                        )
                                      ]
                                    )
                                  ),
                                ),
                              ],
                            ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}