import 'dart:developer';
import 'dart:ui';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:urban_ease_partner/view/widgets/theme_provider.dart';

import '../nav_page.dart';
import '../widgets/custom_snackbar.dart';
import '../widgets/session_data.dart';
import 'forgot_pass.dart';
import 'signup_page.dart';


class LoginPage extends StatefulWidget{
  const LoginPage({super.key});

  @override
  State<StatefulWidget> createState() => _LoginPage();
}

class _LoginPage extends State{
  bool _obsecureText = true;
  final TextEditingController _emailTextEditingController = TextEditingController();
  final TextEditingController _passwordtextEditingController = TextEditingController();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;  
  @override 
  Widget build(BuildContext context){
    final containerTheme = Theme.of(context).extension<CustomContainerTheme>();
    return Scaffold(
      //backgroundColor: const Color(0xFF60CBB0),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "assets\\image1.jpeg",
              fit: BoxFit.cover,
            )),
          Align(
            alignment: Alignment.bottomCenter,
            child: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 8,sigmaY: 8),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height *0.6,
                  decoration:  BoxDecoration(
                    color: containerTheme?.containerColor != Color(0xFFF1EFF1)?Colors.black.withOpacity(0.7):Color(0xFFF1EFF1).withOpacity(0.7),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(40.0),
                      topRight: Radius.circular(40.0),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height *0.04,
                      left:  MediaQuery.of(context).size.height *0.04,
                      right:  MediaQuery.of(context).size.height *0.04,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Let’s Sign You in",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.04,
                            fontWeight: FontWeight.w700,
                            // color: Colors.white
                          ),
                        ),
                        Text(
                          "Welcome Back, You’ve Been Missed!",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.017,
                            fontWeight: FontWeight.w400,
                            // color: Colors.white
                          ),
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height*0.02),
                        Text(
                          "Email or Username",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.017,
                            fontWeight: FontWeight.w400,
                            // color: Colors.white
                          ),
                        ),
                        Container(
                          decoration: const BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 10,
                                spreadRadius: 5,
                                offset: Offset(5, 5)
                              )
                            ]
                          ),
                          child: TextField(
                            controller: _emailTextEditingController,
                            decoration: InputDecoration(
                              prefixIcon: Padding(
                                padding: EdgeInsets.symmetric(
                                  vertical: MediaQuery.of(context).size.height *0.005,
                                  horizontal: MediaQuery.of(context).size.height *0.027,
                                ),
                                child: const Icon(Icons.person_outline_rounded)
                              ),
                              hintText: "Email",
                              hintStyle: GoogleFonts.inter(
                                color: const Color(0xFFA4A4A4), fontSize: MediaQuery.of(context).size.height *0.02,
                                ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              filled: true,
                              fillColor: containerTheme?.containerColor
                            ),
                          ),
                        ),
                        SizedBox(
                        height: MediaQuery.of(context).size.height *0.02,
                      ),
                        Text(
                          "Password",
                          style: GoogleFonts.scada(
                            fontSize: MediaQuery.of(context).size.height *0.017,
                            fontWeight: FontWeight.w400,
                            // color: Colors.white
                          ),
                        ),
                        Container(
                          decoration: const BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 10,
                                spreadRadius: 5,
                                offset: Offset(5, 5)
                              )
                            ]
                          ),
                          child: TextField(
                            controller: _passwordtextEditingController,
                            obscureText: _obsecureText,
                            decoration: InputDecoration(
                              prefixIcon: Padding(
                                padding: EdgeInsets.symmetric(
                                  vertical: MediaQuery.of(context).size.height *0.005,
                                  horizontal: MediaQuery.of(context).size.height *0.027,
                                ),
                                child:const Icon(Icons.lock_outline_rounded)
                              ),
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _obsecureText =! _obsecureText;
                                  });
                                },
                                child:  Padding(
                                  padding: EdgeInsets.symmetric(
                                  vertical: MediaQuery.of(context).size.height *0.005,
                                  horizontal: MediaQuery.of(context).size.height *0.027,
                                ),
                                  child: _obsecureText ? const Icon(Icons.visibility_rounded) : const Icon(Icons.visibility_off_rounded)
                                ),
                              ),
                              hintText: "Password",
                              hintStyle: GoogleFonts.inter(
                                color: const Color(0xFFA4A4A4), fontSize: MediaQuery.of(context).size.height *0.02,
                                ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(
                                  color: Color(0xFF000000),
                                )
                              ),
                              filled: true,
                              fillColor: containerTheme?.containerColor
                            ),
                          ),
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height*0.01),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  PageRouteBuilder(
                                    pageBuilder: (context, animation1, animation2) => const ForgotPasswordPage(),
                                    ));
                              },
                              child: Text(
                                "Forgot password?",
                                style: GoogleFonts.scada(
                                  fontSize: MediaQuery.of(context).size.height *0.017,
                                  fontWeight: FontWeight.w400,
                                  // color: Colors.white
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height*0.055),
                        ElevatedButton(
                            onPressed: () async{
                              if(_emailTextEditingController.text.trim().isNotEmpty && _passwordtextEditingController.text.trim().isNotEmpty){

                                try{
                                  UserCredential userCredential = await _firebaseAuth.signInWithEmailAndPassword(
                                    email: _emailTextEditingController.text, 
                                    password: _passwordtextEditingController.text
                                  );

                                  await SessionData.storeSessionData(
                                    loginData: true, 
                                    nameData: userCredential.user!.displayName!
                                  );
                                  log("USER CREDINTIALS: ${userCredential.user!.displayName}");
                                  Navigator.pushReplacement( context, 
                                    MaterialPageRoute(builder: (context) =>  const NavPage()), 
                                  );
                                } on FirebaseAuthException catch(error){
                                  log(error.code);
                                  log("${error.message}");
                                  CustomSnackbar.showCustomSnackbar(
                                    message: error.message!, 
                                    context: context,
                                  );
                                }
                              }
                            },
                            style: ButtonStyle(
                              elevation: WidgetStateProperty.all(20),
                              shadowColor: WidgetStateProperty.all(Colors.black),
                              padding: WidgetStateProperty.all<EdgeInsets>(
                                  EdgeInsets.zero),
                              shape: WidgetStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.0),
                                ),
                              ),
                            ),
                            child: Ink(
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [ Color(0xFF9184FF), Color(0xFF786AFA)],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                                child: Container(
                                  constraints: BoxConstraints(
                                    maxWidth: MediaQuery.of(context).size.height *0.42,
                                    minHeight: MediaQuery.of(context).size.height *0.06,
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Log in',
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.w600,
                                      fontSize:  MediaQuery.of(context).size.height *0.03,
                                      color: Colors.white,
                                    ),
                                  ),
                                )
                              )
                            ),
                            SizedBox(height: MediaQuery.of(context).size.height*0.0055),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                GestureDetector(
                                  onTap: (){
                                    Navigator.pushAndRemoveUntil(
                                      context,
                                      PageRouteBuilder(
                                        pageBuilder: (context,animation1,animation2) => const SignupPage(),
                                        transitionDuration: Duration.zero,
                                        reverseTransitionDuration: Duration.zero
                                        ),
                                      (Route<dynamic> route) => route.isFirst
                                    );
                                    /*Navigator.push(
                                      context,
                                      PageRouteBuilder(
                                        pageBuilder: (context,animation1,animation2) => const SignupPage(),
                                        transitionDuration: Durations.long1,
                                        reverseTransitionDuration: Duration.zero
                                        )
                                      );*/
                                  },
                                  child: RichText(
                                    text: TextSpan(
                                      text: "Don’t have account? ",
                                        style: GoogleFonts.scada(
                                        fontSize: MediaQuery.of(context).size.height *0.017,
                                        fontWeight: FontWeight.w400,
                                        color: Color(0xFF52367F)
                                      ),
                                      children: [
                                        TextSpan(
                                          text: "Create Account",
                                          style: GoogleFonts.scada(
                                            fontSize: MediaQuery.of(context).size.height *0.017,
                                            fontWeight: FontWeight.w400,
                                            color:const Color(0xFF52367F),
                                            decoration: TextDecoration.underline,
                                          ),
                                        )
                                      ]
                                    )
                                  ),
                                ),
                              ],
                            ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}