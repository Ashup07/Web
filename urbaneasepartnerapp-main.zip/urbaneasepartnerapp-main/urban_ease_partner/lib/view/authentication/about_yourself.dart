import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:urban_ease_partner/view/authentication/login_page.dart';

class AboutYourself extends StatefulWidget {
  const AboutYourself({super.key});

  @override
  State<AboutYourself> createState() => _AboutYourselfState();
}

class _AboutYourselfState extends State<AboutYourself> {
  bool isChecked = false;

  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();

  String selectedCity = 'Pune'; // default value
  String selectedWork = 'Home Security services'; // default value

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 50.0),
                child: Container(
                    padding: const EdgeInsets.only(left: 20, top: 8, bottom: 8),
                    //margin: EdgeInsets.only(left: 20),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          // Start color
                          Color.fromARGB(255, 66, 65, 65),
                          Colors.grey,
                          // End color
                        ],
                      ),
                    ),
                    width: double.infinity,
                    child: Text(
                      "Few more steps to register you as a part of our community !",
                      style: GoogleFonts.poppins(
                          fontSize: 15, color: Colors.white),
                    )),
              ),
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 30.0, top: 30, right: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Tell us about yourself!",
                      style: GoogleFonts.poppins(
                          fontSize: 24, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0, bottom: 5),
                      child: Text(
                        "What's your name?",
                        style: GoogleFonts.poppins(fontSize: 16),
                      ),
                    ),
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(
                        hintText: 'Enter name',
                        hintStyle: GoogleFonts.poppins(
                            color: Colors.grey, fontSize: 14),
                        isDense: true,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 25, vertical: 8),
                        border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(50), // Rounded border
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50),
                          borderSide: const BorderSide(color: Colors.grey),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50),
                          borderSide: const BorderSide(
                              color: Color.fromARGB(255, 77, 0, 191), width: 1),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 20.0, bottom: 5, top: 5),
                      child: Text(
                        "Special Characters like !@#%^&*()_-+={};;-,. are not allowed",
                        style: GoogleFonts.poppins(
                            fontSize: 10, color: Colors.blue),
                      ),
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0, bottom: 5),
                      child: Text(
                        "Phone Number",
                        style: GoogleFonts.poppins(fontSize: 16),
                      ),
                    ),
                    TextField(
                      controller: phoneController,
                      maxLength: 10, // Limit to 10 digits
                      keyboardType:
                          TextInputType.phone, // Makes number keyboard appear
                      decoration: InputDecoration(
                        hintText: 'Enter phone number',
                        hintStyle: GoogleFonts.poppins(
                            color: Colors.grey, fontSize: 14),
                        isDense: true,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 25, vertical: 8),
                        border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(50), // Rounded border
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50),
                          borderSide: const BorderSide(color: Colors.grey),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50),
                          borderSide: const BorderSide(
                              color: Color.fromARGB(255, 77, 0, 191), width: 1),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 20.0, bottom: 5, top: 20),
                      child: Text(
                        "What work do you do?",
                        style: GoogleFonts.poppins(fontSize: 16),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        border: Border.all(color: Colors.grey),
                      ),
                      child: DropdownButtonFormField<String>(
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding:
                              EdgeInsets.symmetric(horizontal: 0, vertical: 8),
                        ),
                        value: null, // Initially no value
                        hint: Text(
                          'Select work',
                          style: GoogleFonts.poppins(),
                        ),
                        icon: const Icon(Icons.keyboard_arrow_down),
                        menuMaxHeight: 200,
                        dropdownColor: Colors.white,
                        items: [
                          'Home Security services',
                          'Electric & Plumbing Services',
                          'Gardening Services',
                          'Pest Control & Cleaning Services',
                          'Home Renovation & Carpenter Services',
                          'Interior Design & Decoration Services',
                          'Home Appliance Repair Services',
                          'Painting & Wall Finishing Services',
                          'Home Moving & Packing Services',
                          'Home Automation & Smart Home Services',
                          'Home Health & Wellness Services',
                        ]
                            .map((work) => DropdownMenuItem(
                                  value: work,
                                  child: Text(
                                    work,
                                    style: GoogleFonts.poppins(),
                                  ),
                                ))
                            .toList(),
                        onChanged: (value) {
                          setState(() {
                            selectedWork = value!;
                          });
                          log('Selected work: $value');
                        },
                      ),
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 20.0, bottom: 5, top: 20),
                      child: Text(
                        "Where do you live?",
                        style: GoogleFonts.poppins(fontSize: 16),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        border: Border.all(color: Colors.grey),
                      ),
                      child: DropdownButtonFormField<String>(
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding:
                              EdgeInsets.symmetric(horizontal: 0, vertical: 8),
                        ),
                        value: null, // Initially no value
                        hint: Text(
                          'Select your city',
                          style: GoogleFonts.poppins(),
                        ),
                        icon: const Icon(Icons.keyboard_arrow_down),
                        menuMaxHeight: 200,
                        dropdownColor: Colors.white,
                        items: [
                          'Mumbai',
                          'Delhi',
                          'Bangalore',
                          'Hyderabad',
                          'Chennai',
                          'Kolkata',
                          'Pune',
                          'Ahmedabad',
                          'Jaipur',
                          'Lucknow',
                          'Indore',
                          'Bhopal',
                          'Chandigarh',
                          'Patna',
                          'Surat',
                          'Nagpur',
                          'Vadodara',
                          'Ludhiana',
                          'Agra',
                          'Varanasi'
                        ]
                            .map((city) => DropdownMenuItem(
                                  value: city,
                                  child: Text(
                                    city,
                                    style: GoogleFonts.poppins(),
                                  ),
                                ))
                            .toList(),
                        onChanged: (value) {
                          setState(() {
                            selectedCity = value!;
                          });
                          log('Selected city: $value');
                        },
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.only(
                        top: 50,
                      ),
                      child: Row(
                        children: [
                          Checkbox(
                            value: isChecked,
                            activeColor: const Color.fromARGB(255, 77, 0, 191),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4)),
                            onChanged: (bool? value) {
                              setState(() {
                                isChecked = value!;
                              });
                            },
                          ),
                          Expanded(
                            child: RichText(
                              text: TextSpan(
                                style: GoogleFonts.poppins(
                                  fontSize: 14,
                                  color: Colors.black,
                                ),
                                children: [
                                  const TextSpan(
                                      text:
                                          'By proceeding, you agree to Urban Company\'s '),
                                  TextSpan(
                                    text: 'Terms & Conditions',
                                    style: const TextStyle(
                                      color: Color.fromARGB(255, 77, 0, 191),
                                      decoration: TextDecoration.underline,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        // Handle Terms & Conditions click
                                        //print('Terms & Conditions clicked');
                                      },
                                  ),
                                  const TextSpan(text: ' and '),
                                  TextSpan(
                                    text: 'Privacy Policy',
                                    style: const TextStyle(
                                      color: Color.fromARGB(255, 77, 0, 191),
                                      decoration: TextDecoration.underline,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        // Handle Privacy Policy click
                                        //print('Privacy Policy clicked');
                                      },
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.13,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 10),
                      child: SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                const Color.fromARGB(255, 77, 0, 191),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                  50), // Same rounded as textfield
                            ),
                            padding: const EdgeInsets.symmetric(
                                vertical: 14), // Height of the button
                          ),
                          onPressed: () async {
                            try {
                              // Reference to Firestore
                              await FirebaseFirestore.instance
                                  .collection('vendors_details')
                                  .add({
                                'name': nameController.text,
                                'city': selectedCity,
                                'phone': phoneController.text,
                                'timestamp': FieldValue
                                    .serverTimestamp(), // Optional: for sorting later
                              });

                              // Show success message
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content:
                                        Text('Data submitted successfully!')),
                              );
                              Navigator.pushReplacement(
                                context,
                                PageRouteBuilder(
                                    pageBuilder:
                                        (context, animation1, animation2) =>
                                            const LoginPage(),
                                    transitionDuration: Duration.zero,
                                    reverseTransitionDuration: Duration.zero));
                            } catch (e) {
                              log('Error adding user: $e');
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Failed to submit data')),
                              );
                            }
                          },
                          child: Text(
                            'Submit',
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
