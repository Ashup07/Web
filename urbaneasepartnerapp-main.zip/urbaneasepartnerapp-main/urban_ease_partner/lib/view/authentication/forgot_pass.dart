
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../widgets/theme_provider.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({super.key});
  @override
  State createState() => _ForgotPasswordPage();
}

class _ForgotPasswordPage extends State {
  void showBottomSheet(CustomContainerTheme containerTheme) {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
        ),
        builder: (context) {
          return Container(
            color: containerTheme.containerColor != Color(0xFFF1EFF1)?Colors.black.withOpacity(0.7):Color(0xFFF1EFF1).withOpacity(0.7),
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
                top: 50,
                left: 30,
                right: 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Verification",
                  style: GoogleFonts.montserrat(
                      fontSize: 26,
                      fontWeight: FontWeight.w700,
                      // color: Colors.black
                    ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  "Enter the OTP code from the phone we\n just sent you.",
                  style: GoogleFonts.montserrat(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      // color: Colors.black
                    ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      height: 68,
                      width: 68,
                      child: TextField(
                        onChanged: (value) {
                          if(value.length == 1){
                            FocusScope.of(context).nextFocus();
                          }
                        },
                        style: const TextStyle(fontSize: 24),
                        textAlign: TextAlign.center,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(1),
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 18, horizontal: 16),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                  color: containerTheme.containerColor != Color(0xFFF1EFF1)?Color(0xFFFFFFFF):Color(0xFF000000), width: 1.5),
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: BorderSide(
                                    color: containerTheme.containerColor != Color(0xFFF1EFF1)?Color(0xFFFFFFFF):Color(0xFF000000), width: 1.5))),
                      ),
                    ),
                    SizedBox(
                      height: 68,
                      width: 68,
                      child: TextField(
                        onChanged: (value) {
                          if(value.length == 1){
                            FocusScope.of(context).nextFocus();
                          }
                        },
                        style: const TextStyle(fontSize: 24),
                        textAlign: TextAlign.center,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(1),
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 18, horizontal: 16),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                  color: containerTheme.containerColor != Color(0xFFF1EFF1)?Color(0xFFFFFFFF):Color(0xFF000000), width: 1.5),
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: BorderSide(
                                    color: containerTheme.containerColor != Color(0xFFF1EFF1)?Color(0xFFFFFFFF):Color(0xFF000000), width: 1.5))),
                      ),
                    ),
                    SizedBox(
                      height: 68,
                      width: 68,
                      child: TextField(
                        onChanged: (value) {
                          if(value.length == 1){
                            FocusScope.of(context).nextFocus();
                          }
                        },
                        style: const TextStyle(fontSize: 24),
                        textAlign: TextAlign.center,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(1),
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 18, horizontal: 16),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                  color: containerTheme.containerColor != Color(0xFFF1EFF1)?Color(0xFFFFFFFF):Color(0xFF000000), width: 1.5),
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: BorderSide(
                                    color: containerTheme.containerColor != Color(0xFFF1EFF1)?Color(0xFFFFFFFF):Color(0xFF000000), width: 1.5))),
                      ),
                    ),
                    SizedBox(
                      height: 68,
                      width: 68,
                      child: TextField(
                        onChanged: (value) {
                          if(value.length == 1){
                            FocusScope.of(context).nextFocus();
                          }
                        },
                        style: const TextStyle(fontSize: 24),
                        textAlign: TextAlign.center,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(1),
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 18, horizontal: 16),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                  color: containerTheme.containerColor != Color(0xFFF1EFF1)?Color(0xFFFFFFFF):Color(0xFF000000), 
                                  width: 1.5),
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: BorderSide(
                                    color: containerTheme.containerColor != Color(0xFFF1EFF1)?Color(0xFFFFFFFF):Color(0xFF000000), 
                                    width: 1.5))),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 40,
                ),
                RichText(
                    text: TextSpan(
                        text: "Didn’t receive OTP code!",
                        style: GoogleFonts.montserrat(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF9184FF),
                          ),
                        children: [
                      TextSpan(
                        text: " Resend",
                        style: GoogleFonts.montserrat(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF786AFA),
                          ),
                      )
                    ])),
                const SizedBox(
                  height: 10,
                ),
                ElevatedButton(
                    onPressed: () {
                      
                    },
                    style: ButtonStyle(
                      elevation: WidgetStateProperty.all(20),
                      shadowColor: WidgetStateProperty.all(Colors.black),
                      padding:
                          WidgetStateProperty.all<EdgeInsets>(EdgeInsets.zero),
                      shape: WidgetStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                    ),
                    child: Ink(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF9184FF), Color(0xFF786AFA)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        child: Container(
                          constraints: const BoxConstraints(
                            maxWidth: 400,
                            minHeight: 60.0,
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            'Verify',
                            style: GoogleFonts.montserrat(
                              fontWeight: FontWeight.w600,
                              fontSize: 28,
                              color: Colors.white,
                            ),
                          ),
                        ))),
                const SizedBox(
                  height: 30,
                )
              ],
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    final containerTheme = Theme.of(context).extension<CustomContainerTheme>();
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "assets\\image1.jpeg",
              fit: BoxFit.cover,
            )),
          Align(
            alignment: Alignment.bottomCenter,
            child: ClipRRect(
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height *0.6,
                decoration:  BoxDecoration(
                  color: containerTheme?.containerColor != Color(0xFFF1EFF1)?Colors.black.withOpacity(0.7):Color(0xFFF1EFF1).withOpacity(0.7),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(40.0),
                    topRight: Radius.circular(40.0),
                  ),
                ),
                child: ListView(
                children: [
                  Container(
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                      /*  gradient: RadialGradient(
                        colors: [
                          Color.fromARGB(255, 76, 160, 163),
                          Color(0xFF3e8e81),
                          Color(0xFF367d7f)
                        ],
                        center: Alignment.center,
                        radius: 0.8,
                      ),*/
                      ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 30.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Forgot password?",
                          style: GoogleFonts.montserrat(
                            fontWeight: FontWeight.w700,
                            fontSize: 34,
                            // color: Colors.white,
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          decoration: const BoxDecoration(boxShadow: [
                            BoxShadow(
                                color: Colors.black26,
                                blurRadius: 10,
                                spreadRadius: 5,
                                offset: Offset(5, 5))
                          ]),
                          child: TextField(
                            decoration: InputDecoration(
                                prefixIcon: const Padding(
                                    padding: EdgeInsets.symmetric(
                                        vertical: 5.0, horizontal: 25),
                                    child: Icon(Icons.mail_outline_rounded)),
                                hintText: "Enter your email address",
                                hintStyle: GoogleFonts.inter(
                                    color: const Color(0xFFA4A4A4), fontSize: 16),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Color(0xFF000000),
                                    )),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Color(0xFF000000),
                                    )),
                                filled: true,
                                fillColor: containerTheme?.containerColor),
                          ),
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Text(
                          "* We will send you a OTP to reset your new password",
                          style: GoogleFonts.montserrat(
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            // color: Colors.white
                          ),
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        ElevatedButton(
                            onPressed: () {
                              showBottomSheet(containerTheme!);
                            },
                            style: ButtonStyle(
                              elevation: WidgetStateProperty.all(20),
                              shadowColor: WidgetStateProperty.all(Colors.black),
                              padding:
                                  WidgetStateProperty.all<EdgeInsets>(EdgeInsets.zero),
                              shape: WidgetStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.0),
                                ),
                              ),
                            ),
                            child: Ink(
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [Color(0xFF9184FF), Color(0xFF786AFA)],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                                child: Container(
                                  constraints: const BoxConstraints(
                                    maxWidth: 400,
                                    minHeight: 60.0,
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Submit',
                                    style: GoogleFonts.montserrat(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 28,
                                      color: Colors.white,
                                    ),
                                  ),
                                ))),
                      ],
                    ),
                  ),
                ),
                          ],
                        ),
                  )
            )
            ) ] ),
      );
  }
}
