import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HelpCenterPage extends StatelessWidget {
  const HelpCenterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: const Color(0xFFFAF8FA),
      appBar: AppBar(
          backgroundColor: const Color(0xFFFFFFFF),
          forceMaterialTransparency: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          title: Text(
            "Help Center",
            style: GoogleFonts.poppins(
                fontSize: 24, fontWeight: FontWeight.w600),
          ),
        ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ListTile(
            title: const Text('FAQ'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('User Guides and Tutorials'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Troubleshooting Guides'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Community Forums'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Contact Support'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Product Updates and Announcements'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Privacy and Security'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Feedback and Suggestions'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Accessibility Information'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Account Management'),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
