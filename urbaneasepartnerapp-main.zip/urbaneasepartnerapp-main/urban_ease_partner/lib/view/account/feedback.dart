import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FeedbackPage extends StatefulWidget {
  const FeedbackPage({super.key});
  @override
  State createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _commentsController = TextEditingController();
  String _feedbackType = 'Bug Report';
  double _rating = 0;

  void _submitFeedback() {
    if (_formKey.currentState!.validate()) {
      // Handle feedback submission logic here
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Feedback submitted successfully!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: const Color(0xFFFAF8FA),
      appBar: AppBar(
          forceMaterialTransparency: true,
          backgroundColor: const Color(0xFFFFFFFF),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          title: Text(
            "Feedback",
            style: GoogleFonts.poppins(
                fontSize: 24, fontWeight: FontWeight.w600),
          ),
        ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const SizedBox(height: 16,),
              Text(
                'Your Feedback Matters',
                style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 16.0),
              const Text(
                'We value your feedback and appreciate your time in helping us improve. Please fill out the form below.',
              ),
              const SizedBox(height: 16.0),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Name (Optional)'),
              ),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(labelText: 'Email (Optional)'),
              ),
              DropdownButtonFormField<String>(
                value: _feedbackType,
                items: ['Bug Report', 'Feature Request', 'General Feedback']
                    .map((label) => DropdownMenuItem(
                          value: label,
                          child: Text(label),
                        ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _feedbackType = value!;
                  });
                },
                decoration: const InputDecoration(labelText: 'Feedback Type'),
              ),
              const SizedBox(height: 16.0),
              const Text(
                'Rating:',
                style: TextStyle(fontSize: 16),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(5, (index) {
                  return IconButton(
                    icon: Icon(
                      index < _rating ? Icons.star : Icons.star_border,
                      color: Colors.yellow,
                    ),
                    onPressed: () {
                      setState(() {
                        _rating = index + 1.0;
                      });
                    },
                  );
                }),
              ),
              TextFormField(
                controller: _commentsController,
                decoration: const InputDecoration(labelText: 'Comments'),
                maxLines: 4,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter your comments';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16.0),
              Center(
                  child: ElevatedButton(
                      onPressed: _submitFeedback,
                      style: ButtonStyle(
                        elevation: WidgetStateProperty.all(5),
                        shadowColor: WidgetStateProperty.all(Colors.black),
                        padding: WidgetStateProperty.all<EdgeInsets>(
                            EdgeInsets.zero),
                        shape: WidgetStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                      ),
                      child: Ink(
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF8A7DFB), Color(0xFF7C6EFC)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Container(
                            constraints:  BoxConstraints(
                              maxWidth: MediaQuery.of(context).size.width,
                              minHeight: 40,
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              'Submit',
                              style: GoogleFonts.poppins(
                                fontWeight: FontWeight.w600,
                                fontSize:
                                    MediaQuery.of(context).size.height * 0.02,
                                color: Colors.white,
                              ),
                            ),
                          ))),
                ),
              const SizedBox(height: 16.0),
              const Text(
                'Note: Your feedback is anonymous unless you choose to provide your contact details. Please refer to our Privacy Policy for more information.',
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 16.0),
              const Text(
                'Contact Us:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const Text('Email: urbaneasepartner@gmail.com'),
              const Text('Phone: +91 76668 79553'),
            ],
          ),
        ),
      ),
    );
  }
}
