import 'dart:developer';

// import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:country_picker/country_picker.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

import '../widgets/theme_provider.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _countryController = TextEditingController();

  final ImagePicker _imagePicker = ImagePicker();
  XFile? _selectedFile;
  // final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  
  // Future<void> uploadImage({required String fileName}) async {
  //   log("ADD IMAGE TO FIREBASE : $fileName");
  //   await FirebaseStorage.instance.ref().child(fileName).putFile(File(_selectedFile!.path));
  // }
  
  // Future<String> downloadImageURL({required String fileName}) async {
  //   log("GET URL TO FIREBASE");
    // String url = await FirebaseStorage.instance.ref().child(fileName).getDownloadURL();
    // log("UPLOADED URL :$url");
    // return url;
  // }

  void addDataToFirebase({required String url}) async{
    log("UPLOAD DATA TO CLOUD");

    ///ADD LOGIC FIREBASE
    Map<String, dynamic> data = {
      'profileImage': url,
    };
    // await FirebaseFirestore.instance.collection("users").add(data);
    log("data added successfully!! $data");
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("User Profile Created Successfully!!"),
      ),
    );
  }

  Future<void> _saveDetails() async {
    log("In SaveDetails _emailController.text, _phoneController.text, _countryController.text}");
    //print(_nameController.text+ _emailController.text+ _phoneController.text+ _countryController.text );
    if (_nameController.text.trim().isNotEmpty && _emailController.text.trim().isNotEmpty && _phoneController.text.trim().isNotEmpty && _countryController.text.trim().isNotEmpty) {
      String fileName = _selectedFile!.name + DateTime.now().toString();
      /// ADD IMAGE TO FIREBASE
      // await uploadImage(fileName: fileName);
      /// GET URL FROM FIREBASE
      // String url = await downloadImageURL(fileName: fileName);
      /// UPLOAD INFO TO CLOUD DATABASE
      // addDataToFirebase(url: url);
      ///GET
      // await getDataFromFirebase();
      setState(() {});
    }else{
      log("enter data carefully");
    }
  }

  void _selectCountry() { 
    showCountryPicker( context: context, 
      showPhoneCode: true, // Optional. Shows phone code before the country name. 
      onSelect: (Country country) { 
        setState(() { 
          _countryController.text = country.name; 
        }); 
      },
    );
  }

  String? urlTemp;
  @override
  Widget build(BuildContext context) {
    final containerTheme = Theme.of(context).extension<CustomContainerTheme>();
    return Scaffold(
        // backgroundColor: const Color(0xFFFAF8FA),
        appBar: AppBar(
          backgroundColor: const Color(0xFFFFFFFF),
          // surfaceTintColor: const Color(0xFFFFFFFF),
          forceMaterialTransparency: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          title: Text(
            "Edit Profile",
            style: GoogleFonts.poppins(
                fontSize: 24, fontWeight: FontWeight.w600),
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 25.0,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10.0),
                        child: Center(
                          child: Container(
                            width:
                                110.0, // Slightly larger than the radius to accommodate border
                            height:
                                110.0, // Slightly larger than the radius to accommodate border
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.black,
                                width: 1.0,
                              ),
                            ),
                            child: GestureDetector(
                              onTap: () async {
                                _selectedFile = await _imagePicker.pickImage(source: ImageSource.gallery);

                                if (_selectedFile != null) {
                                  log("File = ${_selectedFile!.path} ");
                                  // await uploadImage(fileName: _selectedFile.toString());
                                  // urlTemp = await downloadImageURL(fileName: _selectedFile.toString());
                                  // log("Image URL : $urlTemp");

                                  setState(() {});
                                }
                              },
                              child: Stack(
                                children: [
                                (urlTemp != null)
                                ? CircleAvatar(
                                  radius: 60,
                                  backgroundColor: Colors.transparent,
                                  child: ClipOval(
                                    child: Image.network(
                                      urlTemp!, 
                                      fit: BoxFit.cover,
                                      height: 120,
                                      width: 120,
                                    )
                                  ),
                                ):
                                CircleAvatar(
                                  backgroundColor: containerTheme?.containerColor,
                                  radius: 60,
                                  child: const Icon(
                                    Icons.person,
                                    size: 90.0,
                                    
                                  ),
                                ),
                                Positioned(
                                  bottom: -10,
                                  right: -10,
                                  child: IconButton(
                                    icon: const Icon(Icons.camera_alt_rounded,
                                        ),
                                    onPressed: () {},
                                  ),
                                ),
                              ]),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left:  8.0,bottom: 5),
                  child: Text(
                    "Name",
                    style: GoogleFonts.poppins(
                      fontSize: MediaQuery.of(context).size.height * 0.017,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(boxShadow: [
                    BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        spreadRadius: 5,
                        offset: Offset(5, 5))
                  ]),
                  child: TextField(
                     controller: _nameController,
                    decoration: InputDecoration(
                        prefixIcon: Padding(
                            padding: EdgeInsets.symmetric(
                              vertical:
                                  MediaQuery.of(context).size.height * 0.005,
                              horizontal:
                                  MediaQuery.of(context).size.height * 0.027,
                            ),
                            child: const Icon(Icons.person_outline_rounded)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF000000),
                            )),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF7C6EFC),
                            )),
                        filled: true,
                        fillColor: containerTheme?.containerColor),
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.only(left:  8.0,bottom: 5),
                  child: Text(
                    "Email",
                    style: GoogleFonts.poppins(
                      fontSize: MediaQuery.of(context).size.height * 0.017,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(boxShadow: [
                    BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        spreadRadius: 5,
                        offset: Offset(5, 5))
                  ]),
                  child: TextField(
                     controller: _emailController,
                    decoration: InputDecoration(
                        prefixIcon: Padding(
                            padding: EdgeInsets.symmetric(
                              vertical:
                                  MediaQuery.of(context).size.height * 0.005,
                              horizontal:
                                  MediaQuery.of(context).size.height * 0.027,
                            ),
                            child: const Icon(Icons.mail_outline_rounded)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF000000),
                            )),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF7C6EFC),
                            )),
                        filled: true,
                        fillColor: containerTheme?.containerColor),
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.only(left:  8.0,bottom: 5),
                  child: Text(
                    "Phone Number",
                    style: GoogleFonts.poppins(
                      fontSize: MediaQuery.of(context).size.height * 0.017,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(boxShadow: [
                    BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        spreadRadius: 5,
                        offset: Offset(5, 5))
                  ]),
                  child: TextField(
                     controller: _phoneController,
                    decoration: InputDecoration(
                        prefixIcon: Padding(
                            padding: EdgeInsets.symmetric(
                              vertical:
                                  MediaQuery.of(context).size.height * 0.005,
                              horizontal:
                                  MediaQuery.of(context).size.height * 0.027,
                            ),
                            child: const Icon(Icons.phone_android_rounded)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF000000),
                            )),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF7C6EFC),
                            )),
                        filled: true,
                        fillColor: containerTheme?.containerColor),
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.only(left:  8.0,bottom: 5),
                  child: Text(
                    "Select Country",
                    style: GoogleFonts.poppins(
                      fontSize: MediaQuery.of(context).size.height * 0.017,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(boxShadow: [
                    BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        spreadRadius: 5,
                        offset: Offset(5, 5))
                  ]),
                  child: TextField(
                    onTap: _selectCountry,
                    readOnly: true,
                    controller: _countryController,
                    decoration: InputDecoration(
                        prefixIcon: Padding(
                            padding: EdgeInsets.symmetric(
                              vertical:
                                  MediaQuery.of(context).size.height * 0.005,
                              horizontal:
                                  MediaQuery.of(context).size.height * 0.027,
                            ),
                            child: const Icon(Icons.arrow_drop_down_rounded)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF000000),
                            )),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF7C6EFC),
                            )),
                        filled: true,
                        fillColor: containerTheme?.containerColor),
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.only(left:  8.0,bottom: 5),
                  child: Text(
                    "Address",
                    style: GoogleFonts.poppins(
                      fontSize: MediaQuery.of(context).size.height * 0.017,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(boxShadow: [
                    BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        spreadRadius: 5,
                        offset: Offset(5, 5))
                  ]),
                  child: TextField(
                    //  controller: _emailTextEditingController,
                    decoration: InputDecoration(
                        prefixIcon: Padding(
                            padding: EdgeInsets.symmetric(
                              vertical:
                                  MediaQuery.of(context).size.height * 0.005,
                              horizontal:
                                  MediaQuery.of(context).size.height * 0.027,
                            ),
                            child: const Icon(Icons.location_on_rounded)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF000000),
                            )),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide: const BorderSide(
                              color: Color(0xFF7C6EFC),
                            )),
                        filled: true,
                        fillColor: containerTheme?.containerColor),
                  ),
                ),
                const SizedBox(
                      height: 100,
                    ),
                    Center(
                      child: ElevatedButton(
                          onPressed: () async{

                            if(_nameController.text.trim().isNotEmpty ){
                              // User? user = _firebaseAuth.currentUser;
                              //     if (user != null) { 
                              //       log("User created: ${user.uid}");
                              //       await user.updateProfile(
                              //         displayName: _nameController.text,
                              //         photoURL: urlTemp); 
                              //         await user.reload(); 
                              //         user = _firebaseAuth.currentUser;
                              //         log("photo: ${user?.photoURL}");
                              //         log("nameee: ${user?.displayName}");
                              //       }
                            }
                            await _saveDetails();
                            
                            setState(() {
                              log("data added successfully");
                            });
                            Navigator.of(context).pop();
                          },
                          style: ButtonStyle(
                            elevation: WidgetStateProperty.all(20),
                            shadowColor: WidgetStateProperty.all(Colors.black),
                            padding: WidgetStateProperty.all<EdgeInsets>(
                                EdgeInsets.zero),
                            shape:
                                WidgetStateProperty.all<RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                            ),
                          ),
                          child: Ink(
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [Color(0xFF8E82FD), Color(0xFF7C6EFC)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                              child: Container(
                                constraints: const BoxConstraints(
                                  maxWidth: 130,
                                  minHeight: 40,
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  'Save Details',
                                  style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.w600,
                                    fontSize:
                                        MediaQuery.of(context).size.height * 0.02,
                                    color: const Color(0xFFFFFFFF)
                                  ),
                                ),
                              ))),
                    ),
              ],
            ),
          ),
      ));
  }
}
