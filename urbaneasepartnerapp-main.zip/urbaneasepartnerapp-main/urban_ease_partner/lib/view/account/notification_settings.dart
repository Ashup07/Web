import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../widgets/theme_provider.dart';


class Notifications extends StatefulWidget {
  const Notifications({super.key});

  @override
  State<Notifications> createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  bool _valueGeneralNotification = false;
  bool _valueSound = false;
  bool _valueVibrate = false;
  bool _valueAppUpdates = false;
  bool _valueBillRemider = false;
  bool _valueDiscount = false;
  bool _valueNewService = false;
  bool _valueNewTips = false;
  bool _valuePayment = false;

  @override
  Widget build(BuildContext context) {
    final containerTheme = Theme.of(context).extension<CustomContainerTheme>();
    return Scaffold(
        // backgroundColor: const Color(0xFFFAF8FA),
        appBar: AppBar(
          backgroundColor: const Color(0xFFFFFFFF),
          forceMaterialTransparency: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          title: Text(
            "Notifications",
            style: GoogleFonts.poppins(
                fontSize: 24, fontWeight: FontWeight.w600),
          ),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 40, left: 20.0, bottom: 5.0),
              child: Text(
                "Common",
                style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: containerTheme?.containerColor,
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "General Notification",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Color(0xFFFFFFFF)),
                            value: _valueGeneralNotification,
                            onChanged: (value) {
                              setState(() {
                                _valueGeneralNotification = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "Sound",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Colors.white),
                            value: _valueSound,
                            onChanged: (value) {
                              setState(() {
                                _valueSound = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "Vibrate",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Colors.white),
                            value: _valueVibrate,
                            onChanged: (value) {
                              setState(() {
                                _valueVibrate = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
            // const Divider(color: Colors.grey, thickness: 0.5),
            Padding(
              padding: const EdgeInsets.only(top: 30, left: 20.0, bottom: 5.0),
              child: Text(
                "System & services update",
                style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: containerTheme?.containerColor,
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "App updates",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Colors.white),
                            value: _valueAppUpdates,
                            onChanged: (value) {
                              setState(() {
                                _valueAppUpdates = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "Bill Reminder",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Colors.white),
                            value: _valueBillRemider,
                            onChanged: (value) {
                              setState(() {
                                _valueBillRemider = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "Discount Avaiable",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                            ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Colors.white),
                            value: _valueDiscount,
                            onChanged: (value) {
                              setState(() {
                                _valueDiscount = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "Payment Request",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                            ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Colors.white),
                            value: _valuePayment,
                            onChanged: (value) {
                              setState(() {
                                _valuePayment = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
            // const Divider(color: Colors.grey, thickness: 0.5),
            Padding(
              padding: const EdgeInsets.only(top: 30, left: 20.0, bottom: 5.0),
              child: Text(
                "Others",
                style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: containerTheme?.containerColor,
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "New Service Available",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                            ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Colors.white),
                            value: _valueNewService,
                            onChanged: (value) {
                              setState(() {
                                _valueNewService = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0),
                        child: Text(
                          "New Tips Available",
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                            ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: Transform.scale(
                          scale: 0.8,
                          child: Switch(
                            thumbColor: const WidgetStatePropertyAll<Color>(
                                Colors.white),
                            value: _valueNewTips,
                            onChanged: (value) {
                              setState(() {
                                _valueNewTips = value;
                              });
                            },
                            activeColor: const Color(0xFF1900FF),
                            inactiveTrackColor: Colors.grey,
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ],
        ));
  }
}
