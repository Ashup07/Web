import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../widgets/theme_provider.dart';


class TermsOfUseFullScreen extends StatelessWidget {
  const TermsOfUseFullScreen({super.key}); 
  @override
  Widget build(BuildContext context) {
    final containerTheme = Theme.of(context).extension<CustomContainerTheme>();
    return Container(
      //height: MediaQuery.of(context).size.height,
      child: Scaffold(
        // backgroundColor: Colors.white,
        appBar: AppBar(
          forceMaterialTransparency: true,
          toolbarHeight: 80,
          backgroundColor: Colors.white,
          leading: Padding(
            padding: const EdgeInsets.only(top: 25.0),
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ),
          title: Padding(
            padding: const EdgeInsets.only(top: 25.0,),
            child: Text(
              "Terms of Use",
              style: GoogleFonts.poppins(
                  fontSize: 24, fontWeight: FontWeight.w600),
            ),
          ),
        ),
        body: Container(
          color: containerTheme?.containerColor,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              '''UrbanEase Terms of Use
        
            1. Acceptance of Terms: Welcome to Med E-Care. By accessing and using our Medicine Reminder and purchasing Application, you agree to comply with and be bound by these Terms of Use. Please read these Terms carefully. If you do not agree with these Terms, you must not use the App.
        
            2. Eligibility: You must be at least 18 years old to use this App. By using the App, you represent and warrant that you are at least 18 years of age.
        
            
            3. Account Registration: To use certain features of the App, you may need to register for an account. You agree to:
            - Provide accurate, current, and complete information during the registration process.
            - Maintain and promptly update your registration information to keep it accurate, current, and complete.\n- Keep your password confidential and not share it with any third party.\n- Immediately notify us of any unauthorized use of your account.
        
            4. Use of the App: You agree to use the App in compliance with all applicable laws and regulations. You may not:
            - Use the App for any unlawful purpose or for the promotion of illegal activities.\n- Use the App to harass, abuse, or harm another person.\n- Interfere with or disrupt the operation of the App.
        
            5. Medicine Reminder Feature: The Medicine Reminder feature in the App is intended to help you keep track of your medication schedule. However, it is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding your medication or a medical condition. Never disregard professional medical advice or delay in seeking it because of something you have read on the App.
        
            6. Medicine Buying Feature: The App may facilitate the purchase of medicines through third-party providers. We do not sell or distribute medicines ourselves. When you make a purchase through the App, you agree to be bound by the terms and conditions of the third-party provider. We are not responsible for the quality, safety, or legality of the medicines provided by third-party providers.
        
            7. User Content: You may be able to post, submit, or share content, including but not limited to reviews, comments, and feedback. By posting User Content, you grant us a non-exclusive, royalty-free, worldwide, and sublicensable license to use, reproduce, modify, publish, and distribute such User Content. You represent and warrant that you own or have the necessary rights to post your User Content and that your User Content does not violate any third-party rights.
        
            8. Privacy: Your use of the App is also governed by our Privacy Policy, which can be accessed at Link. By using the App, you consent to the collection, use, and sharing of your information as described in the Privacy Policy.
        
            9. Intellectual Property: The App and its content, including but not limited to text, graphics, logos, and software, are the property of [App Name] and are protected by intellectual property laws. You may not use, reproduce, or distribute any content from the App without our prior written permission.
        
            10. Disclaimers: The App is provided "as is" and "as available" without any warranties of any kind, either express or implied. We do not warrant that the App will be uninterrupted, error-free, or free from viruses or other harmful components. To the fullest extent permitted by law, we disclaim all warranties, express or implied, including but not limited to warranties of merchantability, fitness for a particular purpose, and non-infringement.
        
            11. Limitation of Liability: To the fullest extent permitted by law, we shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses, resulting from:\n- Your use or inability to use the App.\n- Any conduct or content of any third party on the App.\n- Any content obtained from the App.\n- Unauthorized access, use, or alteration of your transmissions or content.
        
            12. Indemnification: You agree to indemnify and hold us harmless from any claims, losses, liabilities, damages, expenses, and costs, including reasonable attorneys' fees, arising out of or related to your use of the App or any violation of these Terms.
        
            13. Termination: We may terminate or suspend your access to the App at any time, with or without cause, with or without notice, effective immediately. Upon termination, your right to use the App will immediately cease.
        
            14. Governing Law: These Terms and your use of the App shall be governed by and construed in accordance with the laws of Maharashtra, India, without regard to its conflict of law principles.
        
            15. Changes to Terms: We reserve the right to modify or update these Terms at any time. If we make changes to these Terms, we will provide notice through the App or by other means. Your continued use of the App after such changes indicates your acceptance of the revised Terms.
        
            16. Contact Information: If you have any questions or concerns about these Terms or the App, please contact us at InsightCoders.
            ''',
              style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w400,
                    
                  ),
              textAlign: TextAlign.justify,
            ),
          ),
        ),
      ),
    );
  }
}
