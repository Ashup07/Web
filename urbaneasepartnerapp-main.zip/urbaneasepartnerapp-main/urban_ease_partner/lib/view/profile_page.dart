import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:urban_ease_partner/view/authentication/about_yourself.dart';

import 'account/account_settings.dart';
import 'authentication/login_page.dart';
import 'account/feedback.dart';
import 'account/help_center.dart';
import 'account/notification_settings.dart';
import 'account/terms_of_use.dart';
import 'widgets/theme_provider.dart';
// import 'package:urban_ease_app/view/account/account_settings.dart';
// import 'package:urban_ease_app/view/account/address.dart';
// import 'package:urban_ease_app/view/account/feedback.dart';
// import 'package:urban_ease_app/view/account/help_center.dart';
// import 'package:urban_ease_app/view/account/notification_settings.dart';
// import 'package:urban_ease_app/view/account/terms_of_use.dart';
// import 'package:provider/provider.dart';
// import 'package:urban_ease_app/view/authentication/login_page.dart';
// import 'package:urban_ease_app/view/widgets/theme_provider.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State createState() => _ProfilePage();
}

class _ProfilePage extends State<ProfilePage> {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  Future<void> _signOut(BuildContext context) async {
    final shouldLogout = await _showLogoutConfirmationDialog(context);
    if (shouldLogout) {
      await _firebaseAuth.signOut();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginPage()),
      );
    }
  }

  // SIGNOUT CONFIRM
  Future<bool> _showLogoutConfirmationDialog(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          titlePadding: const EdgeInsets.only(top: 20, left: 80, right: 80),
          title: Text(
            'Confirm Logout',
            style: GoogleFonts.poppins(
              fontSize: 24,
              fontWeight: FontWeight.w600,
              // color: Colors.black
            ),
          ),
          content: Text(
            'Are you sure you want to log out?',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              fontSize: 16,
              // color: Colors.black
            ),
          ),
          actions: [
            
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  Colors.white,
                ),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    side: const BorderSide(
                      color: Colors.black,
                      width: 1.0,
                    ),
                  ),
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop(false); // User cancelled the logout
              },
              child: Text(
                'Cancel',
                style: GoogleFonts.poppins(
                  fontSize: MediaQuery.of(context).size.height * 0.017,
                  fontWeight: FontWeight.w400,
                  color: Colors.black,
                ),
              ),
            ),
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  Colors.black,
                ),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    side: const BorderSide(
                      color: Colors.black,
                      width: 1.0,
                    ),
                  ),
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop(true); // User confirmed the logout
              },
              child: Text(
                'Logout',
                style: GoogleFonts.poppins(
                  fontSize: MediaQuery.of(context).size.height * 0.017,
                  fontWeight: FontWeight.w400,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        );
      },
    ).then((value) => value ?? false);
  }

  @override
  Widget build(BuildContext context) {
    final containerTheme = Theme.of(context).extension<CustomContainerTheme>();
    // final themeProvider = Provider.of<ThemeProvider>(context);
    return FutureBuilder<void>(
      // future: getDataFromFirebase(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else {
          return Scaffold(
              // backgroundColor: const Color(0xFFFFFFFF),
              appBar: AppBar(
                backgroundColor: const Color(0xffffffff),
                forceMaterialTransparency: true,
                /*leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios),
                onPressed: () {},
              ),*/
                title: Text(
                  "My Account",
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    // color: Colors.black
                  ),
                ),
                actions: <Widget>[
                  Consumer<ThemeProvider>(
                    builder: (context, themeProvider, child) {
                      return IconButton(
                          icon: Icon(themeProvider.isDarkMode
                              ? Icons.dark_mode
                              : Icons.light_mode),
                          iconSize: 20,
                          onPressed: () {
                            // setState(() {
                            //   // themeProvider.toggleTheme(!themeProvider.isDarkMode);
                            // });

                            context.read<ThemeProvider>().toggleTheme();
                          });
                    },
                  ),
                ],
              ),
              body: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal:  25.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10.0),
                            child: Container(
                              width:
                                  110.0, // Slightly larger than the radius to accommodate border
                              height:
                                  110.0, // Slightly larger than the radius to accommodate border
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.black,
                                  width: 1.0,
                                ),
                              ),
                              child: CircleAvatar(
                                backgroundColor: containerTheme?.containerColor,
                                radius: 60,
                                child:
                                    //(user.photoURL!= null)
                                    // ?ClipOval(
                                    //   child: Image.network( user.photoURL!,
                                    //   fit: BoxFit.cover,
                                    //   height: 120,
                                    //   width: 120,
                                    //   loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress){
                                    //               if(loadingProgress == null){
                                    //                 return child;
                                    //               }else{
                                    //                 return const Center(
                                    //                   child: CircularProgressIndicator(

                                    //                   ),
                                    //                 );
                                    //               }
                                    //     },
                                    //   ),
                                    // ):
                                    const Icon(
                                  Icons.person,
                                  size: 90.0,
                                  // color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                          Text(
                            _firebaseAuth
                                .currentUser!.displayName!, //"Ruchira",
                            style: GoogleFonts.poppins(
                              fontSize: 24,
                              fontWeight: FontWeight.w600,
                              // color: Colors.black
                            ),
                          ),
                          Text(
                            _firebaseAuth
                                .currentUser!.email!, //"ruchira@gmail.com",
                            style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w400,
                              // color: Colors.black
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 20.0, bottom: 5.0),
                            child: Text(
                              "Manage",
                              style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                // color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: containerTheme?.containerColor,
                            ),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15,),
                                      child: Icon(
                                        Icons.person_rounded,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Complete Profile",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () async {
                                        await Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (context) {
                                          return const EditProfilePage();
                                        })).then((_) => setState(() {}));
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.shopping_bag_outlined,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Job History",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () {
                                        Navigator.of(context).push(
                                          MaterialPageRoute(builder: (context) {
                                        return const AboutYourself();
                                      }));
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.wallet_giftcard_rounded,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Invite a friend to UrbanEase",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () {
                                        // Navigator.of(context).push(
                                        //     MaterialPageRoute(builder: (context) {
                                        //   return const MyWishList();
                                        // })).then((_) => setState(() {}));
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 20.0, bottom: 5.0, top: 10),
                            child: Text(
                              "Settings",
                              style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                // color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: containerTheme?.containerColor,
                            ),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.account_circle_rounded,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Account Settings",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () {
                                        
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.notifications_none,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Notifications Settings",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (context) {
                                          return const Notifications();
                                        }));
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.language_rounded,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Change language",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () {
                                        
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 20.0, bottom: 5.0, top: 10),
                            child: Text(
                              "Others",
                              style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                // color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: containerTheme?.containerColor,
                            ),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.help_outline,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Help Center",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (context) {
                                          return const HelpCenterPage();
                                        }));
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.insert_drive_file,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Terms of Use",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () {
                                        showModalBottomSheet(
                                          context: context,
                                          isScrollControlled: true,
                                          builder: (BuildContext context) {
                                            return const TermsOfUseFullScreen();
                                          },
                                        );
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.feedback_outlined,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Feedback",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (context) {
                                          return const FeedbackPage();
                                        }));
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15),
                                      child: Icon(
                                        Icons.logout_rounded,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      "Logout",
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        // color: Colors.black
                                      ),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      onPressed: () => _signOut(context),
                                      icon: const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ));
        }
      },
      future: null,
    );
  }
}
