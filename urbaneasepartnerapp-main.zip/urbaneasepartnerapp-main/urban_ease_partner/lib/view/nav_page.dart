import 'dart:math';

import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:urban_ease_partner/view/feed_page.dart';
import 'package:urban_ease_partner/view/pocket_page.dart';
import 'package:urban_ease_partner/view/update_page.dart';

import 'profile_page.dart';
import 'widgets/theme_provider.dart';

class NavPage extends StatefulWidget {
  const NavPage({super.key});

  @override
  State createState() => _NavPage();
}

class _NavPage extends State<NavPage> {
  int _selectedIndex = 0;
  bool isOnline = false;
  static final List<Widget> _pages = <Widget>[
    const FeedPage(),
    const PocketPage(),
    const UpdatePage(),
    const ProfilePage(),
  ];

  // List<Color> icon_colors_light = [const Color(0xFFFFFFFF),const Color(0xFFFFFFFF),const Color(0xFFFFFFFF),const Color(0xFFFFFFFF),const Color(0xFFFFFFFF)];

  // List<Color> icon_colors_dark = [const Color(0xFF000000),const Color(0xFF000000),const Color(0xFF000000),const Color(0xFF000000),const Color(0xFF000000)];

  @override
  void initState() {
    super.initState();

    // icon_colors_light[_selectedIndex] = const Color(0xFF7C6EFC);
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  BottomNavigationBar mybottombar() {
    return BottomNavigationBar(
      items: <BottomNavigationBarItem>[
        BottomNavigationBarItem(
          icon: const Padding(
            padding: EdgeInsets.only(top: 15.0, bottom: 5),
            child: Icon(Icons.feed_outlined, size: 25),
          ),
          label: 'Feed',
          backgroundColor: const Color(0xFF181818).withOpacity(1),
        ),
        BottomNavigationBarItem(
          icon: const Padding(
            padding: EdgeInsets.only(top: 15.0, bottom: 5),
            child: Icon(Icons.account_balance_wallet_outlined, size: 25),
          ),
          label: 'Pocket',
          backgroundColor: const Color(0xFF181818).withOpacity(1),
        ),
        BottomNavigationBarItem(
          icon: const Padding(
            padding: EdgeInsets.only(top: 15.0, bottom: 5),
            child: Icon(Icons.notifications_none_sharp, size: 25),
          ),
          label: 'Updates',
          backgroundColor: const Color(0xFF181818).withOpacity(1),
        ),
        BottomNavigationBarItem(
          icon: const Padding(
            padding: EdgeInsets.only(top: 15.0, bottom: 5),
            child: Icon(Icons.person_2_outlined, size: 25),
          ),
          label: 'Profile',
          backgroundColor: const Color(0xFF181818).withOpacity(1),
        ),
      ],
      showUnselectedLabels: true,
      currentIndex: _selectedIndex,
      selectedItemColor: const Color(0xFFE69A15),
      backgroundColor: const Color(0xFF181818).withOpacity(1),
      onTap: _onItemTapped,
      iconSize: 30,
      selectedLabelStyle: GoogleFonts.poppins(
          fontSize: 16), // Increase font size for selected label
      unselectedLabelStyle: GoogleFonts.poppins(fontSize: 16),
    );
  }

  void _showConfirmationDialog() async {
    bool? confirm = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          insetPadding: EdgeInsets.zero, // Remove default padding
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            width: MediaQuery.of(context).size.width, // Full device width
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Confirm Online',
                  style: GoogleFonts.poppins(
                    fontSize: 25,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 5),
                const Divider(
                  color: Colors.grey,
                  thickness: 1,
                ),
                const SizedBox(height: 10),
                Text(
                  'Are you sure you want to go online, you will start receiving bookings',
                  style: GoogleFonts.poppins(fontSize: 16),
                ),
                const SizedBox(height: 40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          side: BorderSide(color: Colors.black, width: 1),
                          padding: EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: Text(
                          'No',
                          style: GoogleFonts.poppins(
                              color: Colors.black,
                              fontSize: 20,
                              fontWeight: FontWeight.w500),
                        ),
                        onPressed: () {
                          Navigator.of(context).pop(false);
                        },
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          side: BorderSide(color: Colors.black, width: 1),
                          padding: EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: Text(
                          'Yes',
                          style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w500),
                        ),
                        onPressed: () {
                          Navigator.of(context).pop(true);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );

    if (confirm == true) {
      setState(() {
        isOnline = true;
      });
    } else {
      setState(() {
        isOnline = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final navBarTheme = Theme.of(context).extension<CustomNavBarTheme>();
    return Scaffold(
      appBar: AppBar(
          toolbarHeight: 80,
          title: Text(
            'UrbanEase Partner',
            style: GoogleFonts.poppins(
                fontSize: 23, fontWeight: FontWeight.w600, color: Colors.black),
          ),
          titleSpacing: 0,
          backgroundColor: Colors.white,
          leading: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset("assets/logo.png"),
          ),

          //     actions: [
          //       Builder(
          //       builder: (context) => IconButton(
          //       icon: const Icon(Icons.menu),
          //       onPressed: () {
          //         Scaffold.of(context).openEndDrawer();
          //         // setState(() {

          //         // });
          //       },
          //     ),
          //     ),
          //     ],
          //   ),
          //   endDrawer: Drawer(
          //   width: MediaQuery.of(context).size.width/1.5,
          //   child: ListView(
          //     padding: EdgeInsets.zero,
          //     children: <Widget>[
          //       const DrawerHeader(
          //         decoration: BoxDecoration(
          //           color: Color(0xFF7C6EFC),
          //         ),
          //         child: Text(
          //           'Menu',
          //           style: TextStyle(
          //             color: Colors.white,
          //             fontSize: 24,
          //           ),
          //         ),
          //         padding: EdgeInsets.all(10),
          //         margin: EdgeInsets.all(0),
          //       ),
          //       ListTile(
          //         leading: const Icon(Icons.home),
          //         selectedTileColor: const Color(0xFF9F9E9E),
          //         title: const Text('Home'),
          //         onTap: () {
          //           Navigator.of(context).pop(MaterialPageRoute(builder: (context){
          //             return const NavPage();
          //           }));
          //         },
          //       ),
          //       ListTile(
          //         leading: const Icon(Icons.note_alt),
          //         title: const Text('Bookings'),
          //         onTap: () {
          //           Navigator.of(context).push(MaterialPageRoute(builder: (context){
          //             return const FeedPage();
          //           }));
          //         },
          //       ),
          //       ListTile(
          //         leading: const Icon(Icons.notifications),
          //         title: const Text('Notifications'),
          //         onTap: () {

          //           Navigator.of(context).push(MaterialPageRoute(builder: (context){
          //             return const PocketPage();
          //           }));
          //         },
          //       ),
          //       ListTile(
          //         leading: const Icon(Icons.favorite),
          //         title: const Text('Wishlist'),
          //         onTap: () {

          //           Navigator.pop(context);
          //         },
          //       ),
          //       ListTile(
          //         leading: const Icon(Icons.person),
          //         title: const Text('My Account'),
          //         onTap: () {

          //           Navigator.of(context).push(MaterialPageRoute(builder: (context){
          //             return const ProfilePage();
          //           }));
          //         },
          //       ),
          //       ListTile(
          //         leading: const Icon(Icons.settings),
          //         title: const Text('Settings'),
          //         onTap: () {

          //           Navigator.of(context).push(MaterialPageRoute(builder: (context){
          //             return const ProfilePage();
          //           }));
          //         },
          //       ),
          //     ],
          //   ),
          // ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 15.0),
              child: FlutterSwitch(
                value: isOnline,
                onToggle: (value) {
                  if (value) {
                    _showConfirmationDialog();
                  } else {
                    setState(() {
                      isOnline = false;
                    });
                  }
                },
                activeText: "Online",
                inactiveText: "Offline",
                activeColor: Colors.green,
                inactiveColor: Colors.grey,
                activeTextColor: Colors.white,
                inactiveTextColor: Colors.white,
                valueFontSize: 15.0,
                width: 90,
                height: 30,
                borderRadius: 30.0,
                showOnOff: true,
              ),
            ),
            const Icon(Icons.notifications_none_sharp,
                size: 30, color: const Color(0xFF000000)),
            const SizedBox(width: 10),
          ],
          bottom: const PreferredSize(
            preferredSize: Size.fromHeight(1.0), // thickness of the line
            child: Divider(
              color: Colors.black,
              thickness: 1,
              height: 1,
            ),
          )),
      body: Center(
        child: _pages.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: mybottombar(),
    );
  }
}
