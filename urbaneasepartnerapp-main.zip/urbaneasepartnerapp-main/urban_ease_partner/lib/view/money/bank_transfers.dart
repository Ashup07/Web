import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BankTransfers extends StatefulWidget {
  const BankTransfers({super.key});

  @override
  State<BankTransfers> createState() => _BankTransfersState();
}

class _BankTransfersState extends State<BankTransfers> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            "All Bank Transfers",
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          backgroundColor: const Color(0xFFFFFFFF),
          bottom: const PreferredSize(
            preferredSize: Size.fromHeight(1.0), // thickness of the line
            child: Divider(
              color: Colors.black,
              thickness: 0.5,
              height: 1,
            ),
          )),
      body: Column(
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              
              const SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "10 - 13 Apr",
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      // color: Colors.black
                    ),
                  ),
                  Text(
                    "Upcoming",
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      // color: Colors.black
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Text(
                    "₹ 0",
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      // color: Colors.black
                    ),
                  ),
              IconButton(
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) {
                    return const BankTransfers();
                  }));
                },
                icon: const Icon(
                  Icons.arrow_forward_ios_rounded,
                  size: 15,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
