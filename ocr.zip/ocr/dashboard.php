<?php
$page = "Dashboard";
include_once("./adders/header.php");

date_default_timezone_set('Asia/Kolkata');

$getComplaints = json_decode(select_query($con, "*", "complaint_master", "status='open'", "", "", ""));

function timeInterval($time)
{
	$updated_datetime = new DateTime($time);
	$elapsed_time = '';
	$today = new DateTime();
	$interval = $today->diff($updated_datetime);

	$elapsed_time .= $interval->y != 0 ? $interval->y . ' Yr ' : '';
	$elapsed_time .= $interval->m != 0 ? $interval->m . ' Mo ' : '';
	$elapsed_time .= $interval->d != 0 ? $interval->d . ' Da ' : '';
	$elapsed_time .= $interval->h != 0 ? $interval->h . ' Hr ' : '';
	$elapsed_time .= $interval->i != 0 ? $interval->i . ' Min ' : '';
	$elapsed_time .= $interval->s != 0 ? $interval->s . ' Sec ' : '';
	$elapsed_time .= ' Ago';

	return $elapsed_time;
}
?>
<!--Container Main start-->
<div class="m-3">
	<div class="row">
		<h4 class="text-uppercase"><?php echo $page; ?></h4>
	</div>

	<div class="container-fluid px-0">
		<div class="row">
			<div class="col-md-2">
				<ul class="nav flex-column nav-pills mb-3" id="pills-tab" role="tablist">
					<li class="nav-item">
						<a class="nav-link active" id="pills-open-tab" data-toggle="pill" href="#pills-open" role="tab" aria-controls="pills-open" aria-selected="true">Open</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="pills-closed-tab" data-toggle="pill" href="#pills-closed" role="tab" aria-controls="pills-closed" aria-selected="false">Resovled</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="pills-cancelled-tab" data-toggle="pill" href="#pills-cancelled" role="tab" aria-controls="pills-cancelled" aria-selected="false">Cancelled</a>
					</li>
				</ul>
			</div>
			<div class="col-md-8">
				<div class="tab-content" id="pills-tabContent">
					<div class="tab-pane fade show active" id="pills-open" role="tabpanel" aria-labelledby="pills-open-tab">
						<div class="row">
							<div class="col-md-3">
								<?php
								$cnt = 0;
	
								$getAvailableRdCount = json_decode(select_query($con, "COUNT(*) as rdcount", "complaint_master", "complaint_against='rd' and status='open'", "", "", ""));
								$getLastUpdateOfRd = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='rd' and status='open'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableRdCount[0]->rdcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfRd[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableRdCount[0]->rdcount; ?></h4>
										<p class="card-text text-dark">Road Damage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailableElCount = json_decode(select_query($con, "COUNT(*) as elcount", "complaint_master", "complaint_against='el' and status='open'", "", "", ""));
								$getLastUpdateOfEl = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='el' and status='open'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableElCount[0]->elcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfEl[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableElCount[0]->elcount; ?></h4>
										<p class="card-text text-dark">Electricity</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailabledrCount = json_decode(select_query($con, "COUNT(*) as drcount", "complaint_master", "complaint_against='dr' and status='open'", "", "", ""));
								$getLastUpdateOfDr = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='dr' and status='open'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailabledrCount[0]->drcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfDr[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailabledrCount[0]->drcount; ?></h4>
										<p class="card-text text-dark">Drainage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailableplCount = json_decode(select_query($con, "COUNT(*) as plcount", "complaint_master", "complaint_against='pl' and status='open'", "", "", ""));
								$getLastUpdateOfpl = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='pl' and status='open'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableplCount[0]->plcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfpl[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableplCount[0]->plcount; ?></h4>
										<p class="card-text text-dark">Pipe-Leakage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="pills-closed" role="tabpanel" aria-labelledby="pills-closed-tab">
						<div class="row">
							<div class="col-md-3">
								<?php
								$cnt = 0;
	
								$getAvailableRdCount = json_decode(select_query($con, "COUNT(*) as rdcount", "complaint_master", "complaint_against='rd' and status='resolved'", "", "", ""));
								$getLastUpdateOfRd = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='rd' and status='resolved'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableRdCount[0]->rdcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfRd[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableRdCount[0]->rdcount; ?></h4>
										<p class="card-text text-dark">Road Damage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailableElCount = json_decode(select_query($con, "COUNT(*) as elcount", "complaint_master", "complaint_against='el' and status='resolved'", "", "", ""));
								$getLastUpdateOfEl = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='el' and status='resolved'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableElCount[0]->elcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfEl[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableElCount[0]->elcount; ?></h4>
										<p class="card-text text-dark">Electricity</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailabledrCount = json_decode(select_query($con, "COUNT(*) as drcount", "complaint_master", "complaint_against='dr' and status='resolved'", "", "", ""));
								$getLastUpdateOfDr = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='dr' and status='resolved'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailabledrCount[0]->drcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfDr[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailabledrCount[0]->drcount; ?></h4>
										<p class="card-text text-dark">Drainage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailableplCount = json_decode(select_query($con, "COUNT(*) as plcount", "complaint_master", "complaint_against='pl' and status='resolved'", "", "", ""));
								$getLastUpdateOfpl = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='pl' and status='resolved'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableplCount[0]->plcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfpl[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableplCount[0]->plcount; ?></h4>
										<p class="card-text text-dark">Pipe-Leakage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="pills-cancelled" role="tabpanel" aria-labelledby="pills-cancelled-tab">
						<div class="row">
							<div class="col-md-3">
								<?php
								$cnt = 0;
	
								$getAvailableRdCount = json_decode(select_query($con, "COUNT(*) as rdcount", "complaint_master", "complaint_against='rd' and status='denied'", "", "", ""));
								$getLastUpdateOfRd = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='rd' and status='denied'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableRdCount[0]->rdcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfRd[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableRdCount[0]->rdcount; ?></h4>
										<p class="card-text text-dark">Road Damage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailableElCount = json_decode(select_query($con, "COUNT(*) as elcount", "complaint_master", "complaint_against='el' and status='denied'", "", "", ""));
								$getLastUpdateOfEl = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='el' and status='denied'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableElCount[0]->elcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfEl[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableElCount[0]->elcount; ?></h4>
										<p class="card-text text-dark">Electricity</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailabledrCount = json_decode(select_query($con, "COUNT(*) as drcount", "complaint_master", "complaint_against='dr' and status='denied'", "", "", ""));
								$getLastUpdateOfDr = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='dr' and status='denied'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailabledrCount[0]->drcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfDr[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailabledrCount[0]->drcount; ?></h4>
										<p class="card-text text-dark">Drainage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<?php
								$getAvailableplCount = json_decode(select_query($con, "COUNT(*) as plcount", "complaint_master", "complaint_against='pl' and status='denied'", "", "", ""));
								$getLastUpdateOfpl = json_decode(select_query($con, "updated_datetime", "complaint_master", "complaint_against='pl' and status='denied'", "updated_datetime DESC", "1", ""));
	
								$elapsed_time = '0 Hr 0 Min 0 Sec Ago';
								if ($getAvailableplCount[0]->plcount > 0) {
									$elapsed_time = timeInterval($getLastUpdateOfpl[0]->updated_datetime);
								}
								?>
								<div class="card">
									<div class="card-body text-center">
										<h4 class="card-title text-dark"><?php echo $getAvailableplCount[0]->plcount; ?></h4>
										<p class="card-text text-dark">Pipe-Leakage</p>
										<p class="card-text"><small class="text-muted"><?php echo $elapsed_time; ?></small></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row mt-4">
		<div class="accordion w-100" id="accordionExample">
			<?php
			foreach ($getComplaints as $complaint) { ?>
				<div class="card request<?php echo $complaint->id; ?>">
					<div class="card-header bg-white" id="heading<?php echo $complaint->id; ?>">
						<div class="row mb-0" data-toggle="collapse" data-target="#collapse<?php echo $complaint->id; ?>" aria-expanded="true" aria-controls="collapse<?php echo $complaint->id; ?>">
							<div class="col">
								<p class="font-weight-bold text-muted mb-0 d-inline">Name</p>
								<p><?php echo $complaint->first_name . ' ' . $complaint->last_name; ?></p>
							</div>
							<div class="col">
								<p class="font-weight-bold text-muted mb-0 d-inline">Complaints Against</p>
								<p><?php echo $complaint->complaint_against == 'rd' ? 'Road Damage' : ($complaint->complaint_against == 'el' ? 'Elecricity' : ($complaint->complaint_against == 'dr' ? 'Drainage' : ($complaint->complaint_against == 'pl' ? 'Pipe-Leakage' : ''))); ?></p>
							</div>
							<div class="col">
								<p class="font-weight-bold text-muted mb-0 d-inline">Address</p>
								<p><?php echo $complaint->address; ?></p>
							</div>
							<div class="col">
								<p class="font-weight-bold text-muted mb-0 d-inline">Phone</p>
								<p><?php echo $complaint->phone_number; ?></p>
							</div>
							<div class="col">
								<p class="font-weight-bold text-muted mb-0 d-inline">Action</p>
								<p>
									<button type="button" id="<?php echo $complaint->id; ?>" class="btn btn-outline-success btn-sm request-accept-btn my-1 rounded-circle"><i class="fas fa-check"></i></button>
									<button type="button" id="<?php echo $complaint->id; ?>" class="btn btn-outline-danger btn-sm request-deny-btn rounded-circle"><i class="fas fa-times"></i></button>
								</p>
							</div>
						</div>
					</div>

					<div id="collapse<?php echo $complaint->id; ?>" class="collapse" aria-labelledby="heading<?php echo $complaint->id; ?>" data-parent="#accordionExample">
						<div class="card-body">
							<h5><b><?php echo $complaint->first_name . ' ' . $complaint->last_name; ?></b></h5>
							<?php echo $complaint->description; ?>
						</div>
					</div>
				</div>
			<?php }
			?>
		</div>
	</div>
</div>
<?php
include_once "./adders/footer.php";
?>
<script>
	$(document).on('click', '.request-accept-btn', function(event) {
		event.stopPropagation();
		$('button').addClass('disabled');
		var a = this.id;

		$.ajax({
			url: './controller/requestHandler.php',
			type: 'POST',
			data: {
				requestId: a,
				flag: 'accept',
			},
			success: function(result) {
				data = JSON.parse(result);
				if (data[0] == true) {
					$('.request' + a).remove();
				}
			}
		})

		$('button').removeClass('disabled');
	});

	$(document).on('click', '.request-deny-btn', function(event) {
		event.stopPropagation();
		$('button').addClass('disabled');
		var a = this.id;

		$.ajax({
			url: './controller/requestHandler.php',
			type: 'POST',
			data: {
				requestId: a,
				flag: 'deny',
			},
			success: function(result) {
				data = JSON.parse(result);
				if (data[0] == true) {
					$('.request' + a).remove();
				}
			}
		})

		$('button').removeClass('disabled');
	});
</script>