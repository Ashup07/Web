<?php
$page = "Register Complaint";
include_once("./adders/header.php");
?>
<!--Container Main start-->
<div class="m-3">
	<div class="row">
		<h4 class="text-uppercase"><?php echo $page; ?></h4>
	</div>

	<h5 class="w-100 text-center"><b>Select section in which you want to register complaint</b></h5>
	<div class="row mt-4">
		<div class="col-md-2"></div>
		<div class="col-md-4">
			<div class="card slider w-50 mx-auto" id="rd">
				<div class="card-body">
					<h5 class="card-title w-100 text-primary text-center">
						<i class="fas fa-road"></i>
					</h5>
					<p class="w-100 text-center">Road Damage</p>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="card slider w-50 mx-auto" id="el">
				<div class="card-body">
					<h5 class="card-title w-100 text-primary text-center">
						<i class="fas fa-bolt"></i>
					</h5>
					<p class="w-100 text-center">Electricity</p>
				</div>
			</div>
		</div>
		<div class="col-md-2"></div>
	</div>

	<div class="row mt-4">
		<div class="col-md-2"></div>
		<div class="col-md-4">
			<div class="card slider w-50 mx-auto" id="dr">
				<div class="card-body">
					<h5 class="card-title w-100 text-primary text-center">
						<i class="fas fa-faucet"></i>
					</h5>
					<p class="w-100 text-center">Drainage</p>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="card slider w-50 mx-auto" id="pl">
				<div class="card-body">
					<h5 class="card-title w-100 text-primary text-center">
						<i class="fas fa-tools"></i>
					</h5>
					<p class="w-100 text-center">Pipe-Leakage</p>
				</div>
			</div>
		</div>
		<div class="col-md-2"></div>
	</div>
</div>
<?php
include_once('./adders/footer.php');
?>
<script>
	$('.card').on('click', function() {
		var id = this.id;
		window.location.href = "add_complaint.php?q=" + id;
	})
</script>