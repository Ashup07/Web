<?php
define("db_servername", "localhost");
define("db_username","root");
define("db_password","");
define("db_database", "ocr");

// define("db_servername", "sql112.epizy.com");
// define("db_username","epiz_28439472");
// define("db_password","FYBWqAROafJvC2");
// define("db_database", "epiz_28439472_testify");