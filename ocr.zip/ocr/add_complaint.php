<?php
$page = "Add Complaint";
include_once "./adders/header.php";

$complaint_for = $_GET['q'];
$fnameErr = $lnameErr = $addressErr = $emailErr = $phoneErr = $descriptionErr = '';

if (isset($_POST['subRequest'])) {
    $fname = mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['fname'])));
    $lname = mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['lname'])));
    $address = mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['address'])));
    $description = mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['description'])));
    $email = mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['email'])));
    $phone = mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['phone'])));

    if ($fname == '')
        $fnameErr = "Please enter first name";

    if ($lname == '')
        $lnameErr = "Please enter last name";

    if ($address == '')
        $addressErr = "Please enter address";

    if ($email == '')
        $emailErr = "Please enter email id";

    if ($phone == '')
        $phoneErr = "Please enter phone number";

    if ($description == '')
        $descriptionErr = 'Please enter description or enter NA';

    if ($complaint_for != '' && $fnameErr == '' && $lnameErr == '' && $addressErr == '' && $emailErr == '' && $phoneErr == '' && $descriptionErr == '') {
        $complaintColumns = array('complaint_against', 'first_name', 'last_name', 'address', 'email_id', 'phone_number', 'description');
        $complaintValue = array($complaint_for, $fname, $lname, $address, $email, $phone, $description);

        $complaintId = insert_query($con, $complaintColumns, $complaintValue, "complaint_master");

        if ($complaintId != '') {
            echo '<script>swal({title: "Your complaint has been submitted successfully",type: "success",button: "Ok"}).then(function() {window.location.href = "index.php";});</script>';
        } else {
            echo '<script>swal({title: "Something went wrong",type: "warning",button: "Ok"});</script>';
        }
    }
}
?>
<!--Container Main start-->
<div class="m-3 form-div">
    <div class="row">
        <h4 class="text-uppercase"><?php echo $page; ?></h4>
    </div>

    <form action="" method="POST" class="validate-form">
        <label class="mt-3"><b>Registering complaint against</b></label>
        <div class="row">
            <div class="col-md-3 my-2">
                <div class="card organ-card" id="<?php echo $complaint_for ?>">
                    <div class="card-body text-center">
                        <?php echo $complaint_for == 'rd' ? '<i class="fas fa-road"></i> Road Damage' : ($complaint_for == 'el' ? '<i class="fas fa-bolt"></i> Elecricity' : ($complaint_for == 'dr' ? '<i class="fas fa-faucet"></i> Drainage' : ($complaint_for == 'pl' ? '<i class="fas fa-tools"></i> Pipe-Leakage' : ''))); ?>
                    </div>
                </div>
            </div>
        </div>

        <label class="my-3 locality-label"><b>Complainee Details</b></label>
        <div class="row locality-div">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="">First Name</label>
                    <input type="text" class="form-control form-control-sm" name="fname" placeholder="First name">
                    <?php echo $fnameErr != '' ? '<span class="text-danger">'. $fnameErr .'</span>' : ''; ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="">Last Name</label>
                    <input type="text" class="form-control form-control-sm" name="lname" placeholder="Last name">
                    <?php echo $lnameErr != '' ? '<span class="text-danger">'. $lnameErr .'</span>' : ''; ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="">Address</label>
                    <textarea type="text" class="form-control form-control-sm" rows="1" name="address" placeholder="Address"></textarea>
                    <?php echo $addressErr != '' ? '<span class="text-danger">'. $addressErr .'</span>' : ''; ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="">Complaint Description</label>
                    <textarea name="description" rows="1" class="form-control form-control-sm" placeholder="Please enter detailed desease description"></textarea>
                    <small class="text-muted">
                        If you don't have any decease fill it with NA
                    </small>
                    <?php echo $descriptionErr != '' ? '<span class="text-danger">'. $descriptionErr .'</span>' : ''; ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="">Email Id</label>
                    <input type="text" class="form-control form-control-sm" name="email" placeholder="Email id">
                    <?php echo $emailErr != '' ? '<span class="text-danger">'. $emailErr .'</span>' : ''; ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="">Phone Number</label>
                    <input type="text" class="form-control form-control-sm" name="phone" placeholder="Phone Number">
                    <?php echo $phoneErr != '' ? '<span class="text-danger">'. $phoneErr .'</span>' : ''; ?>
                </div>
            </div>
        </div>

        <div class="row pl-3 locality-div">
            <div class="form-group">
                <input type="submit" class="btn btn-sm btn-outline-primary" value="Submit" name="subRequest">
            </div>
        </div>
    </form>

</div><!-- /.container-fluid -->
<?php
include_once "./adders/footer.php";
?>