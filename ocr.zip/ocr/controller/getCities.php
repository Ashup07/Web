<?php
ob_start();
session_start();

include_once "../config/database.php";
include_once "./functions.php";

$state = decryption(mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['s']))));

$getCities = json_decode(select_query($con, "*", "city", "state_id=" . $state, "name", "", ""));

if (!empty($getCities)) { ?>
    
    <option value="" disabled selected>Select City</option> 
    
    <?php 
    foreach ($getCities as $city) { ?>
        <option value="<?php echo encryption($city->id)?>"><?php echo $city->name; ?></option>
    <?php }
}
