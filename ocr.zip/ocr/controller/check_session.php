<?php

session_start();
if($page == 'Dashboard' && $_SESSION['logged_in'] != 1)
    header("Location: login.php");