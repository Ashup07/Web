<?php
ob_start();
session_start();

include_once "../config/database.php";
include_once "./functions.php";

$request_id = mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['requestId'])));
$flag = mysqli_real_escape_string($con, htmlspecialchars(trim($_POST['flag'])));

if ($flag == 'accept') {
    $result[] = update_query($con, "complaint_master", "status='resolved'", "id=" . $request_id);
}

if ($flag == 'deny') {
    $result[] = update_query($con, "complaint_master", "status='denied'", "id=" . $request_id);
}

echo json_encode($result);
