$.fn.modal.Constructor.prototype.enforceFocus = function () {};

$(".department-select").select2();

$(".student-select").select2();

$(".year-select").select2();

$(".ranking-year-select").select2();

$(".ranking-dept-select").select2();
